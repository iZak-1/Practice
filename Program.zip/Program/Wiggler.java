public class Wiggler
{
  private int myX, myY;
  public Wiggler()
  {
    myX = myY = 150;
  }
  public void setX(int x_) {
    myX=x_;
  }
  public void setY(int y_) {
    myY=y_;
  }
  public float getY() {
    return(myY);
  }
  public float getX() {
    return(myX);
  }
  public void wiggle()
  {
    myX+=(int)(Math.random()*5)-2;
  }
}
